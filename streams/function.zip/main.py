def dynamodb_events(event, context):
  print('New event')
  print(event)